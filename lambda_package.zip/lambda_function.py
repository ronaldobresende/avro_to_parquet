import json
import boto3
import os
import fastavro
import pandas as pd
from io import BytesIO

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # Buckets S3
    source_bucket = 'bucket_pouso'
    destination_bucket = 'bucket_sor_1'
    
    # Processar cada arquivo Avro criado
    for record in event['Records']:
        avro_file_key = record['s3']['object']['key']
        
        # Baixar o arquivo Avro do bucket S3
        avro_obj = s3_client.get_object(Bucket=source_bucket, Key=avro_file_key)
        avro_body = avro_obj['Body'].read()
        
        # Ler o arquivo Avro
        bytes_reader = BytesIO(avro_body)
        reader = fastavro.reader(bytes_reader)
        records = [record for record in reader]
        
        # Converter os registros Avro para DataFrame Pandas
        df = pd.DataFrame(records)
        
        # Achatar os campos aninhados de forma genérica
        df_flat = pd.concat([df.drop(['data'], axis=1), df['data'].apply(pd.Series)], axis=1)
        
        # Converter o DataFrame para Parquet em memória
        parquet_buffer = BytesIO()
        df_flat.to_parquet(parquet_buffer, index=False)
        
        # Upload do arquivo Parquet para o bucket de destino S3
        parquet_key = avro_file_key.replace('.avro', '.parquet')
        s3_client.put_object(Bucket=destination_bucket, Key=parquet_key, Body=parquet_buffer.getvalue())
        
        print(f'Sucesso: {avro_file_key} convertido para {parquet_key}')
    
    return {
        'statusCode': 200,
        'body': json.dumps('Processamento concluído com sucesso')
    }
